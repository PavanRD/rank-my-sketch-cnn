"""
# The judge server. Your friend's drawing website talks to this over HTTP.

# Endpoints
# ---------
# GET  /categories        -> words the model actually knows how to score
# POST /round/start        {"word": "car"}                -> starts a new round
# POST /submit             multipart form: image=<file>, player=<name>
#                           -> scores the drawing against the round's word
# GET  /leaderboard        -> current round's submissions, ranked

# Run with:  python server.py   (serves on http://localhost:5000)
# """

import io
import json
import os

import numpy as np
from flask import Flask, jsonify, request
from flask_cors import CORS
from PIL import Image
import tensorflow as tf

from sketch_utils import preprocess_pil_image

MODEL_PATH = "sketch_model.keras"
CATEGORIES_PATH = "categories.json"

app = Flask(__name__)
CORS(app)  # allow your friend's website (a different origin) to call this API

if not os.path.exists(MODEL_PATH) or not os.path.exists(CATEGORIES_PATH):
    raise SystemExit(
        "No trained model found. Run `python train_model.py` first "
        "(it creates sketch_model.keras and categories.json)."
    )

print("Loading model...")
model = tf.keras.models.load_model(MODEL_PATH)
with open(CATEGORIES_PATH) as f:
    CATEGORIES = json.load(f)
WORD_TO_INDEX = {w: i for i, w in enumerate(CATEGORIES)}
print(f"Ready. Model knows {len(CATEGORIES)} words.")

# All state lives in memory for simplicity. Restarting the server clears it.
# Good enough for a local game night; swap for a real DB before a public launch.
current_round = {"word": None, "submissions": []}


def score_image(pil_image: Image.Image, target_word: str):
    """Returns (percentage_for_target, top_guess_word, top_guess_percentage)."""
    x = preprocess_pil_image(pil_image)
    probs = model.predict(x, verbose=0)[0]  # shape (num_categories,)

    target_idx = WORD_TO_INDEX[target_word]
    target_pct = round(float(probs[target_idx]) * 100, 1)

    top_idx = int(np.argmax(probs))
    top_word = CATEGORIES[top_idx]
    top_pct = round(float(probs[top_idx]) * 100, 1)

    return target_pct, top_word, top_pct


@app.route("/categories", methods=["GET"])
def get_categories():
    return jsonify({"categories": CATEGORIES})


@app.route("/round/start", methods=["POST"])
def start_round():
    data = request.get_json(silent=True) or {}
    word = (data.get("word") or "").strip().lower()

    if word not in WORD_TO_INDEX:
        return jsonify({
            "error": f"'{word}' isn't a word this model was trained on.",
            "hint": "See GET /categories for the valid word list.",
        }), 400

    current_round["word"] = word
    current_round["submissions"] = []
    return jsonify({"status": "ok", "word": word})


@app.route("/submit", methods=["POST"])
def submit():
    if current_round["word"] is None:
        return jsonify({"error": "No round in progress. Call /round/start first."}), 400

    if "image" not in request.files:
        return jsonify({"error": "No 'image' file in the request."}), 400

    player = request.form.get("player", "Anonymous")
    file_bytes = request.files["image"].read()

    try:
        pil_image = Image.open(io.BytesIO(file_bytes))
    except Exception:
        return jsonify({"error": "Could not read the uploaded file as an image."}), 400

    target_word = current_round["word"]
    target_pct, top_word, top_pct = score_image(pil_image, target_word)

    entry = {
        "player": player,
        "score": target_pct,
        "top_guess": top_word,
        "top_guess_score": top_pct,
    }
    current_round["submissions"].append(entry)

    return jsonify({
        "word": target_word,
        "score": target_pct,
        "message": f"The model thinks that's {top_pct}% '{top_word}'"
                   + ("" if top_word == target_word else f" (target was '{target_word}')"),
    })


@app.route("/leaderboard", methods=["GET"])
def leaderboard():
    ranked = sorted(current_round["submissions"], key=lambda e: e["score"], reverse=True)
    for i, entry in enumerate(ranked, start=1):
        entry["rank"] = i
    return jsonify({"word": current_round["word"], "leaderboard": ranked})


@app.route("/", methods=["GET"])
def test_page():
    """A tiny manual test page so you can try the API before wiring up the real site."""
    words_html = ", ".join(CATEGORIES)
    return f"""
    <html><body style="font-family: sans-serif; max-width: 480px; margin: 40px auto;">
      <h2>Sketch Judge - test page</h2>
      <p><b>Known words:</b> {words_html}</p>

      <h3>1. Start a round</h3>
      <input id="word" placeholder="e.g. car">
      <button onclick="startRound()">Start</button>
      <pre id="roundOut"></pre>

      <h3>2. Submit a drawing</h3>
      <input id="player" placeholder="player name" value="Test Player">
      <input id="file" type="file" accept="image/*">
      <button onclick="submitDrawing()">Submit</button>
      <pre id="submitOut"></pre>

      <h3>3. Leaderboard</h3>
      <button onclick="refreshLeaderboard()">Refresh</button>
      <pre id="lbOut"></pre>

      <script>
        async function startRound() {{
          const word = document.getElementById('word').value;
          const res = await fetch('/round/start', {{
            method: 'POST', headers: {{'Content-Type': 'application/json'}},
            body: JSON.stringify({{word}})
          }});
          document.getElementById('roundOut').textContent = JSON.stringify(await res.json(), null, 2);
        }}
        async function submitDrawing() {{
          const player = document.getElementById('player').value;
          const file = document.getElementById('file').files[0];
          const fd = new FormData();
          fd.append('player', player);
          fd.append('image', file);
          const res = await fetch('/submit', {{ method: 'POST', body: fd }});
          document.getElementById('submitOut').textContent = JSON.stringify(await res.json(), null, 2);
        }}
        async function refreshLeaderboard() {{
          const res = await fetch('/leaderboard');
          document.getElementById('lbOut').textContent = JSON.stringify(await res.json(), null, 2);
        }}
      </script>
    </body></html>
    """


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
