"""
Shared image preprocessing for the sketch-judging game.

The whole system only works if a drawing gets turned into a 28x28 array
the SAME way at training time (Quick, Draw! bitmaps) and at judging time
(a screenshot/PNG exported from your friend's canvas). This module is the
single place that does that conversion so the two can never drift apart.
"""

import numpy as np
from PIL import Image

IMG_SIZE = 28


def _to_grayscale_array(pil_image: Image.Image) -> np.ndarray:
    """Flatten any mode (RGBA, RGB, P, L...) down to a 2D grayscale array."""
    if pil_image.mode in ("RGBA", "LA"):
        # Composite onto white first, so a transparent canvas background
        # doesn't get treated as "ink".
        background = Image.new("RGB", pil_image.size, (255, 255, 255))
        background.paste(pil_image, mask=pil_image.split()[-1])
        pil_image = background
    gray = pil_image.convert("L")
    return np.array(gray, dtype=np.float32)


def _normalize_polarity(arr: np.ndarray) -> np.ndarray:
    """
    Force the convention: background ~ 0 (dark), ink/strokes ~ high values.

    We don't assume whether the source used "black pen on white paper" or
    the opposite -- we detect it. The outer border of an image is almost
    always background (drawings are roughly centered), so we compare the
    border's average brightness to the whole image's average brightness.
    If the border is brighter than the drawing, the image is
    "dark strokes on light background" and we invert it.
    """
    h, w = arr.shape
    border_pixels = np.concatenate([
        arr[0, :], arr[-1, :], arr[:, 0], arr[:, -1]
    ])
    border_mean = border_pixels.mean()
    overall_mean = arr.mean()

    if border_mean > overall_mean:
        arr = 255.0 - arr
    return arr


def _bbox_crop_and_square_pad(arr: np.ndarray, pad_frac: float = 0.15) -> np.ndarray:
    """
    Crop to the bounding box of the "ink" (non-background) pixels, then
    pad back out to a square. This mirrors how Quick, Draw! bitmaps are
    centered on the drawing rather than the canvas -- important because a
    player's canvas is much bigger than their doodle.
    """
    threshold = arr.max() * 0.15  # anything reasonably bright counts as ink
    ys, xs = np.where(arr > threshold)

    if len(xs) == 0 or len(ys) == 0:
        # Blank image -- nothing was drawn. Just return as-is (all background).
        return arr

    x0, x1 = xs.min(), xs.max()
    y0, y1 = ys.min(), ys.max()
    cropped = arr[y0:y1 + 1, x0:x1 + 1]

    ch, cw = cropped.shape
    side = int(max(ch, cw) * (1 + pad_frac))
    square = np.zeros((side, side), dtype=np.float32)
    y_off = (side - ch) // 2
    x_off = (side - cw) // 2
    square[y_off:y_off + ch, x_off:x_off + cw] = cropped
    return square


def preprocess_pil_image(pil_image: Image.Image) -> np.ndarray:
    """
    Full pipeline for a LIVE submitted drawing (arbitrary size PNG/JPEG
    from a browser canvas) -> model-ready (1, 28, 28, 1) float32 array
    in [0, 1].
    """
    arr = _to_grayscale_array(pil_image)
    arr = _normalize_polarity(arr)
    arr = _bbox_crop_and_square_pad(arr)

    img = Image.fromarray(arr.astype(np.uint8))
    img = img.resize((IMG_SIZE, IMG_SIZE), Image.LANCZOS)
    arr = np.array(img, dtype=np.float32) / 255.0
    return arr.reshape(1, IMG_SIZE, IMG_SIZE, 1)


def preprocess_quickdraw_row(row: np.ndarray) -> np.ndarray:
    """
    Preprocess ONE row from a Quick, Draw! numpy_bitmap .npy file
    (shape (784,), uint8) into the same (28, 28, 1) float32 [0,1] format.
    Quick, Draw! bitmaps are already centered/cropped, so we only need to
    fix polarity and normalize -- no bbox crop needed.
    """
    arr = row.reshape(IMG_SIZE, IMG_SIZE).astype(np.float32)
    arr = _normalize_polarity(arr)
    return (arr / 255.0).reshape(IMG_SIZE, IMG_SIZE, 1)
