"""
Trains a CNN to recognize hand-drawn sketches, using Google's Quick, Draw!
dataset (50M+ real player doodles, 28x28 grayscale, one .npy file per word).

Run this once (or whenever you change CATEGORIES) before starting server.py:

    python train_model.py

It downloads one .npy file per category (~20-100MB each, cached locally so
re-runs are fast), trains a small CNN, and saves:
    sketch_model.keras   <- the trained model
    categories.json      <- ordered list of words the model can score

IMPORTANT: the model can ONLY score words it was trained on. Whatever word
list your game uses must be a subset of CATEGORIES below (or something you
add and retrain on). The full list of ~345 available Quick Draw categories
is at:
https://raw.githubusercontent.com/googlecreativelab/quickdraw-dataset/master/categories.txt
"""

import json
import os
import urllib.parse
import urllib.request

import numpy as np
import tensorflow as tf

from sketch_utils import preprocess_quickdraw_row, IMG_SIZE

# ---------------------------------------------------------------------------
# 1. Pick your game's word list here. Every word MUST match a Quick Draw
#    category name exactly (see the categories.txt link above).
# ---------------------------------------------------------------------------
CATEGORIES = [
    "car", "cat", "dog", "house", "tree", "sun", "star", "fish",
    "bicycle", "airplane", "umbrella", "cup", "chair", "clock", "flower",
    "guitar", "hat", "key", "ladder", "moon", "pizza", "rainbow",
    "shoe", "snowman", "spider", "bird", "book", "cloud",
    "crown", "diamond",
]
CATEGORIES = sorted(set(CATEGORIES))  # de-dupe, stable order

SAMPLES_PER_CATEGORY = 6000   # more = better accuracy, slower download/train
EPOCHS = 12
DATA_DIR = "quickdraw_data"
BASE_URL = "https://storage.googleapis.com/quickdraw_dataset/full/numpy_bitmap/"


def download_category(word: str) -> str:
    os.makedirs(DATA_DIR, exist_ok=True)
    path = os.path.join(DATA_DIR, f"{word}.npy")
    if not os.path.exists(path):
        url = BASE_URL + urllib.parse.quote(word) + ".npy"
        print(f"  downloading {word!r} ...")
        urllib.request.urlretrieve(url, path)
    return path


def load_dataset():
    X, y = [], []
    print(f"Preparing data for {len(CATEGORIES)} categories:")
    for label_idx, word in enumerate(CATEGORIES):
        path = download_category(word)
        rows = np.load(path)
        rows = rows[:SAMPLES_PER_CATEGORY]
        print(f"  {word}: {len(rows)} samples")
        for row in rows:
            X.append(preprocess_quickdraw_row(row))
        y.extend([label_idx] * len(rows))

    X = np.stack(X).astype("float32")
    y = np.array(y, dtype="int64")

    # shuffle
    perm = np.random.default_rng(42).permutation(len(X))
    return X[perm], y[perm]


def build_model(num_classes: int) -> tf.keras.Model:
    model = tf.keras.Sequential([
        tf.keras.layers.Input(shape=(IMG_SIZE, IMG_SIZE, 1)),
        tf.keras.layers.Conv2D(32, 3, activation="relu", padding="same"),
        tf.keras.layers.MaxPooling2D(),
        tf.keras.layers.Conv2D(64, 3, activation="relu", padding="same"),
        tf.keras.layers.MaxPooling2D(),
        tf.keras.layers.Conv2D(128, 3, activation="relu", padding="same"),
        tf.keras.layers.MaxPooling2D(),
        tf.keras.layers.Flatten(),
        tf.keras.layers.Dense(256, activation="relu"),
        tf.keras.layers.Dropout(0.3),
        tf.keras.layers.Dense(num_classes, activation="softmax"),
    ])
    model.compile(
        optimizer="adam",
        loss="sparse_categorical_crossentropy",
        metrics=["accuracy"],
    )
    return model


def main():
    X, y = load_dataset()
    n_val = int(len(X) * 0.1)
    X_val, y_val = X[:n_val], y[:n_val]
    X_train, y_train = X[n_val:], y[n_val:]

    model = build_model(len(CATEGORIES))
    model.summary()

    model.fit(
        X_train, y_train,
        validation_data=(X_val, y_val),
        epochs=EPOCHS,
        batch_size=256,
    )

    val_loss, val_acc = model.evaluate(X_val, y_val, verbose=0)
    print(f"\nFinal validation accuracy: {val_acc:.1%}")

    model.save("sketch_model.keras")
    with open("categories.json", "w") as f:
        json.dump(CATEGORIES, f, indent=2)

    print("Saved sketch_model.keras and categories.json")


if __name__ == "__main__":
    main()
